<?php
/**
 * templates loader view
 */
?>
<div class="elementskit-filters-list"></div>
<div class="elementskit-templates-wrap">
	<div class="elementskit-keywords-list"></div>
	<div class="elementskit-templates-list"></div>
</div>