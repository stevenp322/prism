<?php
/**
 * Trustpilot widget for Elements kit
 */

namespace Elementor;

use \ElementsKit\Elementskit_Widget_Trustpilot_Handler as Handler;

if (!defined('ABSPATH')) exit;

class Elementskit_Widget_Trustpilot extends Widget_Base
{

    public function get_name()
    {
        return Handler::get_name();
    }

    public function get_title()
    {
        return Handler::get_title();
    }

    public function get_icon()
    {
        return Handler::get_icon();
    }

    public function get_categories()
    {
        return Handler::get_categories();
    }

    public function render()
    {

        $results = Handler::get_data()->result;
        foreach ($results as $result):
        ?>
            <div class="ekit-trustpilot-review">
                <img src="<?php echo $result->reviewer->avatar_url ?>">
                <h3>      <?php echo esc_html__($result->reviewer->name) ?></h3>
                <h2>      <?php echo esc_html__($result->rating) ?>        </h2>
                <p>       <?php echo esc_html__($result->text) ?>          </p>
                <small>   <?php echo esc_html__($result->created_at) ?>    </small>
            </div>
        <?php
        endforeach;

    }


}