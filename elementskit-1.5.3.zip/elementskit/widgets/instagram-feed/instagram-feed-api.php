<?php
namespace ElementsKit\Widgets\Instagram_Feed;

use ElementsKit\Core\Handler_Api;
use ElementsKit\Elementskit_Widget_Instagram_Feed_Handler;

defined('ABSPATH') || exit;

class Instagram_Feed_Api extends Handler_Api {
    public function config(){
        $this->prefix = 'widget/instagram-feed';

    }

    public function get_refresh_feed(){
        Elementskit_Widget_Instagram_Feed_Handler::reset_cache();
        Elementskit_Widget_Instagram_Feed_Handler::get_instagram_feed();
    }


}


