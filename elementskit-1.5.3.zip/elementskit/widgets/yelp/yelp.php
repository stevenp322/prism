<?php
/**
 * Yelp widget for ElementsKit
 */

namespace Elementor;

use \ElementsKit\Elementskit_Widget_Yelp_Handler as Handler;

if (!defined('ABSPATH')) exit;

class Elementskit_Widget_Yelp extends Widget_Base
{

    public function get_name()
    {
        return Handler::get_name();
    }

    public function get_title()
    {
        return Handler::get_title();
    }

    public function get_icon()
    {
        return Handler::get_icon();
    }

    public function get_categories()
    {
        return Handler::get_categories();
    }

    public function render()
    {
        $data = Handler::get_data();
        if (isset($data->error)):
            return;
        else:
            foreach ($data->reviews as $review):
                ?>
                <div class="ekit-yelp-review-item">
                    <img width="100" src="<?php echo $review->user->image_url ?>">
                    <a href="<?php echo $review->user->profile_url; ?>" target="_blank">
                        <?php echo esc_html__($review->user->name, 'elementskit') ?>
                    </a>
                    <h1><?php echo esc_html__($review->rating, 'elementskit') ?></h1>
                    <p>
                        <?php echo esc_html__($review->text, 'elementskit') ?>
                    </p>
                    <small> <?php echo esc_html__($review->time_created, 'elementskit') ?></small>
                </div>
            <?php
            endforeach;

        endif;
    }
}
